<html>
 <head>
 </head>
 <body>   
    <div class="form">	<div class="container text-container">
    <form method="POST" action="formInsert.php">
      <p >
      <label  for="email">Email </label>
      <input type="text" name="email" id="email">
      </p>
      <p >
      <label for="password">Password</label>
      <input type="text" name="password" id="password">
      </p>
      <p >  
	  <label for="firstName">First Name </label>
      <input type="text" name="firstName" id="firstName">
      </p>
      <p>
      <label for="lastName">Last Name </label>
      <input type="text" name="lastName" id="lastName">
      </p>
	  <p>
      <label for="address">Address</label>
      <input type="text" name="address" id="address">
      </p>
	  <p>

      <input type="submit" name="submit" id="submit" value="Submit">
      </p>
</text-container>
    </form>
</body>
</html>